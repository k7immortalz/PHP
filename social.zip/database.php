<?php
	$db=new mysqli("localhost","root","","hobby");
	if(!$db)
	{
		echo "failed";
	}
	
?>