 
<?php
    include"database.php";
    session_start();
    
?>

 <?php
           
           //rank update starts
            $s="SELECT * FROM rank  WHERE UID='".$_SESSION["UID"]."'";

                                $res=$db->query($s);
                                if($res->num_rows>0)
                                {
                                    $rank1=0;
                                    $rank2=0;
                                    $rank3=0;
                                    $overrank=0;
                                    $i=0;

                                    while($r=$res->fetch_assoc())
                                    {  
                                        $i++;
                                     $rank1 += $r['RANK1']; 
                                     $rank2 += $r['RANK2']; 
                                     $rank3 += $r['RANK3']; 
                                     
                                    }
                                    echo $i;
                                      
                                        $overrank = $rank1 + $rank2 + $rank3;
                                        $overrank = $overrank / ($i * 3);
                                        echo"<br>";
                                        echo $overrank;


  $sq="update user set UPRANK='{$overrank}' where UID = {$r["UID"]}";
  echo $sq;
          
       
         
                           
                            if($db->query($sq))
                            {
                             
                                echo '<script>alert("Thank you! Your work has been updated. Have a nice day..")</script>';
                                echo "<script>window.open('home.php','_self');</script>";
                            }
                            else
                            {
                                echo '<script>alert("Sorry! Cant Update Your Work")</script>';
                               // echo "<script>window.open('tasks.php','_self');</script>";
                            }
                            

                                }
                                else
                                {
                                    echo "No Record Found";
                                }
                            //end of rank update
                            
            
          ?>