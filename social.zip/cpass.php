<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/cpass.css">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-wEmeIV1mKuiNpC+IOBjI7aAzPcEZeedi5yW5f2yOq55WWLwNGmvvx4Um1vskeMj0" crossorigin="anonymous">

    <title>Post Page</title>
  </head>
  <body>

<?php include 'header.php';?>
<section id="changepassword">
  <div class="hoverpass">
  <div class="boxchange neuro">
    <img src="images/avatar/lock.png">
    <form>
      <label>Old Password</label>
      <input type="text" name="" placeholder="Enter Old Password" class="form-control">
      <br>

      <label>New Password</label>
      <input type="text" name="" placeholder="Enter New Password" class="form-control">
<br>
        <label>Confirm   Password</label>
      <input type="text" name="" placeholder="Re-Enter Password" class="form-control">
      <br>
      <label class="checkbox-inline">
      <input type="checkbox" value=""><span>I Agree to Change</span>
    </label>
    <br>
      <br>
      
      <button class="form-control"> Submit </button>
      <h2>
      <a href="#"> send me new password<i class="fas fa-caret-right"></i></a>
      </h2>
    </form>
  </div>
  </div>
<!------end of box change---->
</section>
<!-------end of changepassword---------->

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-p34f1UUtsS3wqzfto5wAAmdvj+osOnFyQFpp4Ua3gs/ZVWx6oOypYoCJhGGScy+8" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.min.js" integrity="sha384-lpyLfhYuitXl2zRZ5Bn2fqnhNAKOAaM/0Kr9laMspuaMiZfGmfwRNFh8HlMy49eQ" crossorigin="anonymous"></script>
    -->
  </body>
</html>