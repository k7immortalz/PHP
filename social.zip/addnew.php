
<section id="addnew">
  <div class="container">
    <div class="row">
      <div class="col-md-8">
        <div class="message">
          <a href="#" data-bs-toggle="modal" data-bs-target="#staticBackdrop" class="boxa">
          <div class="box">
            <i class="fas fa-plus"></i>
           </div>
           <!-------end of box------>
        </a>

        <div class="modelboot">
          <!-- Scrollable modal -->


<!-- Modal -->
<div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <div class="title_container">
      <h2 class="completereg">Whats in your Mind?</h2>
          </div>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
       <section id="postform">
  <div class="hoverpass">
 <div class="form_wrapper">
  <div class="form_container">
        <div class="row clearfix">
      <div class="">
        <?php
            if(isset($_POST["postsubmit"]))
            {
              $sq="insert into post(UID,PTITLE,PDESCRIPTION,PHASHTAG) values('{$_SESSION["UID"]}','{$_POST["ptitle"]}','{$_POST["pdescription"]}','{$_POST["phashtag"]}')";
              echo $sq;
             
              if($db->query($sq))
              {
                echo "<script>window.open('post.php','_self');</script>";
              }
              else
              {
                  echo '<script>alert("Please Try Again")</script>';
              }
              
            }
            
          ?>
          <form method="post" action="<?php echo $_SERVER["PHP_SELF"];?>">
           <label>Title</label>
          <div class="input_field">
           <span><i class="fas fa-heading"></i></span>
            <input class="form-control" name="ptitle" placeholder="Enter Heading" />
        
          </div>
          <!--------end of labelinput-------->
           <label>Description</label>
          <div class="input_field">
           <span style="height:62px;"><i class="fas fa-file-medical-alt"></i></span>
            <textarea class="form-control" name="pdescription" placeholder="Describe yourself here..." >
              </textarea>
        
          </div>
          <!--------end of labelinput-------->

          <label>Hashtag</label>
          <div class="input_field">
           <span><i class="fab fa-slack-hash"></i></span>
            <input  class="form-control" name="phashtag" placeholder="Choose Category" value="#" />
         
          </div>
          <!--------end of labelinput-------->
         
         
                <br>
                    <!--------end of labelinput-------->
                        <div class="input_field">
           <span><i class="fas fa-paperclip"></i></span>
            <input  class="form-control" type="file" name="phashtag" placeholder="Choose Category"  value="#" />
         
          </div>
            <!---end of border upload--->
            <br>
         
     
          <input name="postsubmit" class="primbtn" type="submit" value="Post" />
        </form>
      </div>
    </div>
  </div>
  </div>
</div>
<!------ending all--->
</section></div></div></div></div></div></div></div></div></div>
</section>
