<?php
    include"database.php";
    session_start();
    
    if(!isset($_SESSION["UID"]))
    {
        echo"<script>window.open('index.php?mes=Access Denied...','_self');</script>";
        
    }   
    $text1 = $_POST['PID'];
    $text2 = $_POST['PUID'];
    $text3 = $_POST['PCCOMMENT'];
    
$sql = "INSERT INTO postcomment (PID, PUID, PCCOMMENT)
VALUES ('$text1', '$text2', '$text3')";

if ($db->query($sql) === TRUE) {
  
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}
$count = $_POST['count2'];
$sql1 = "SELECT PCCOMMENT FROM postcomment WHERE PID='$text1' AND PUID='$text2' ORDER BY PCID DESC LIMIT $count";
$result1 = mysqli_query($db, $sql1);

if (mysqli_num_rows($result1) > 0) {
  // output data of each row
  while($row1 = mysqli_fetch_assoc($result1)) {
      ?>
      <div class="flexprocomment">
            
            <div class="flexitprocomment">
               <div class="profphocomment" style="background-image:url("images/login/fluid-designs.jpg")";>
            
          </div>
            </div>
   <div class="flexitprocomment">
              <h2><span>My namddddde </span><br> 20 Seconds Ago</h2>
            </div>
            <!------end of flexitpro----->
          </div>
          <p><?php echo "<p> " . $row1["PCCOMMENT"]. " </p> ";?></p>
          <div class="linecomment"></div>
      <?php
    
  }
} else {
  echo "0 results";
}
?>