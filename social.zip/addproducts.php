<?php
  include"database.php";
  session_start();
 
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta class="form-control" name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/profile.css">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-wEmeIV1mKuiNpC+IOBjI7aAzPcEZeedi5yW5f2yOq55WWLwNGmvvx4Um1vskeMj0" crossorigin="anonymous">

    <title>Post Page</title>
  </head>
  <body>
    <?php include 'header.php';?>
<section id="regform">
  <div class="hoverpass">
 <div class="form_wrapper neuro">
  <div class="form_container">
    <div class="title_container">
      <h2>List Your Products  </h2>
          </div>
    <div class="row clearfix">
      <div class="">
        <?php
            if(isset($_POST["submit"]))
            {

              $target="images/products/";
              $target_file=$target.basename($_FILES["img"]["name"]);
              
              if(move_uploaded_file($_FILES['img']['tmp_name'],$target_file))
              {

              $sq="insert into market(PRUID,PRNAME,PRNUM,PRDESCRIPTION,PRPRICE,PRIMG) values('{$_SESSION["UID"]}','{$_POST["prname"]}','{$_POST["prnum"]}','{$_POST["prdescription"]}','{$_POST["prprice"]}','{$target_file}')";
              echo $sq;
             
              if($db->query($sq))
              {
                echo "<div class='success'>Insert Success</div>";
                echo "<script>window.open('market.php','_self');</script>";
              }
              else
              {
                  echo '<script>alert("Please Try Again")</script>';
              }
              
            }}
            
          ?>
          <form  enctype="multipart/form-data" role="form"  method="post" action="<?php echo $_SERVER["PHP_SELF"];?>">
          <label>Product Name</label>
          <div class="input_field">
           <span><i class="fas fa-user-tie"></i></span>
            <input maxlength="20" type="text" class="form-control" name="prname" placeholder="Enter Product name" required />
          </div>
          <!--------end of labelinput-------->
           <label>Choose Image</label>
          <div class="input_field">
           <span><i class="fas fa-user-tie"></i></span>
            <input type="file" class="form-control" name="img" placeholder="Upload Image" required />
          </div>
          <!--------end of labelinput-------->
           <label>Phone Number</label>
          <div class="input_field">
           <span><i class="fas fa-user-tie"></i></span>
            <input type="number" maxlength="10" class="form-control" name="prnum" placeholder="Enter Phone Number" required />
          </div>
          <!--------end of labelinput-------->
           <label>Selling Price</label>
          <div class="input_field">
           <span><i class="far fa-envelope"></i></span>
            <input type="number" class="form-control" name="prprice" placeholder="Add Cost [INR]" required />
          </div>
          <!--------end of labelinput-------->
           <label>Description</label>
         
           
            <textarea maxlength="50" type="date" class="form-control" name="prdescription" placeholder="Describe Product Details.." required /></textarea>
         
          <!--------end of labelinput-------->
            <input required="required" type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
            <label for="vehicle3"> I Accept Terms and Conditions</label><br><br>
          
         
          <!--------end of labelinput-------->
          <input class="button" type="submit" value="Upload" name="submit" />
        </form>
      </div>
    </div>
  </div>
  </div>
</div>

</section>
<!------end of regform--------->


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-p34f1UUtsS3wqzfto5wAAmdvj+osOnFyQFpp4Ua3gs/ZVWx6oOypYoCJhGGScy+8" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.min.js" integrity="sha384-lpyLfhYuitXl2zRZ5Bn2fqnhNAKOAaM/0Kr9laMspuaMiZfGmfwRNFh8HlMy49eQ" crossorigin="anonymous"></script>
    -->
  </body>
</html>