<?php
  include "database.php";
  session_start();
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-wEmeIV1mKuiNpC+IOBjI7aAzPcEZeedi5yW5f2yOq55WWLwNGmvvx4Um1vskeMj0" crossorigin="anonymous">

    <title>Login page</title>
  </head>
  <body>

  <section id="loginform">
    <div class="logincont container">
     <div class="row">
       <div class="col-md-6 loginleft">
         <div class="glassleft">
           <h2 class="apname">The App <br> Name</h2>
           <div class="sdiv"></div>
           <h3 class="spanname"><span>We Are</span><br>Invite Only Right Now</h3>
           <p>This is the paragraph text this is the paragraph text this is the paragraph text. </p>
           <h3  class="abh2"><a href="forgotpass.php">Forgot Password </a>
            
          </h3>

         </div>
         
           
        
         <!------end of glass left----->
       </div>
       <!---end of col 6----->
       <div class="col-md-6 loginright container">
        <div class="focont">
         <h2>sign In</h2>
        <?php
        if(isset($_POST["login"]))
        {
          $sql="select * from user where UNAME='{$_POST["uname"]}' and UPASS='{$_POST["upass"]}'";
          $res=$db->query($sql);
          if($res->num_rows>0)
          {
            $ro=$res->fetch_assoc();
            $_SESSION["UID"]=$ro["UID"];
            $_SESSION["UNAME"]=$ro["UNAME"];
            echo "<script>window.open('post.php','_self');</script>";
          }
          else
          {
            echo '<script>alert("Please Enter Correct User ID and Password")</script>';
          }
          
        }
        if(isset($_GET["mes"]))
        {
          echo "<div class='error'>{$_GET["mes"]}</div>";
        }
        
      ?>
    
        <form method="post" action="<?php echo $_SERVER["PHP_SELF"];?>">
           <label>Email address</label>
           <br>
           <input type="" name="uname" placeholder="Enter Your User ID"  class="form-control" >
           
           <label>Password</label>
           <br>
           <input type="password"  id="loginpass" name="upass" placeholder="Enter Password"  class="form-control" >
           
           <input style="margin-right: 10px;" type="checkbox"  class="form-check-input"  onclick="myFunction()">Show Password

            <script>
            function myFunction() {
              var x = document.getElementById("loginpass");
              if (x.type === "password") {
                x.type = "text";
              } else {
                x.type = "password";
              }
            }
            </script>
            <br><br>
                       <input type="submit" name="login"  class="form-control primbtn" >

         </form>
         <div class="orclass"></div>
         <br>
         <button class="form-control primbtn" onclick="window.location.href='registration.php'">Register Here</button>
       </div>
       <!----end of focont------>
       </div>
       <!---end of col 6----->
     </div>
     <!---end of row---->
    </div>
  </section>
<!-----end of login form------->

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-p34f1UUtsS3wqzfto5wAAmdvj+osOnFyQFpp4Ua3gs/ZVWx6oOypYoCJhGGScy+8" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.min.js" integrity="sha384-lpyLfhYuitXl2zRZ5Bn2fqnhNAKOAaM/0Kr9laMspuaMiZfGmfwRNFh8HlMy49eQ" crossorigin="anonymous"></script>
    -->
  </body>
</html>