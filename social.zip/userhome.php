
<?php
    include"database.php";
    session_start();
    $id=$_GET['id'];
    if(!isset($_SESSION["UID"]))
    {
        echo"<script>window.open('login.php?mes=Access Denied...','_self');</script>";
        
    }   
?>
 
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-wEmeIV1mKuiNpC+IOBjI7aAzPcEZeedi5yW5f2yOq55WWLwNGmvvx4Um1vskeMj0" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="css/home.css">

    <link rel="stylesheet" type="text/css" href="css/style.css">

    <link rel="stylesheet" type="text/css" href="css/addnew.css">

<style>
    .slidervalues::after{
        content: '%'!important;
    }
</style>
    <title>User Home</title>
  </head>
  <body>

    <body>
     <?php include 'header.php';?>


<section id="maincontent">
  <div class="container">
    <div class="row">
      
      <div class="col-md-4 one">
        <div class="left-container ">
                <div class="menu-box block neuro"> <!-- MENU BOX (LEFT-CONTAINER) -->
                    <h2 class="titular">MENU BOX</h2>
                    <ul class="menu-box-menu">
                        <li>
                            <a class="menu-box-tab" href="#6"><span class="icon fontawesome-envelope scnd-font-color"></span>Messages<div class="menu-box-number"></div></a>                            
                        </li>
                        <li>
                            <a class="menu-box-tab" href="#8"><span class="icon entypo-paper-plane scnd-font-color"></span>Invites<div class="menu-box-number"></div></a>                            
                        </li>
                        <li>
                            <a class="menu-box-tab" href="#10"><span class="icon entypo-calendar scnd-font-color"></span>Events<div class="menu-box-number"></div></a>                            
                        </li>
                        <li>
                            <a class="menu-box-tab" href="#12"><span class="icon entypo-cog scnd-font-color"></span>Account Settings</a>
                        </li>
                        <li>
                            <a class="menu-box-tab" href="#13"><sapn class="icon entypo-chart-line scnd-font-color"></sapn>Statistics</a>
                        </li>                        
                    </ul>

                </div>
                 <div class="tweets block neuro"> <!-- TWEETS (MIDDLE-CONTAINER) -->
                    <h2 class="titular"><span class="icon"><i class="fas fa-comment-alt"></i></i></span>Recent Comments</h2>
                       <?php 
               $slcomment="SELECT * FROM postcomment  where PUID = {$_SESSION["UID"]} ORDER BY PCID DESC LIMIT 3 ";
              $rcomment=$db->query($slcomment);
                if($rcomment->num_rows>0)
                  {
                   
                    while($rocomment=$rcomment->fetch_assoc())
                    {
                      echo "

                    <div class='tweet first'>
                     <p><a href='userhome.php?id={$rocomment['PUID']}' class='btnr'>{$rocomment['PUID']} My name</a>
                       {$rocomment['PUID']}</p>
                        <p>{$rocomment['PCCOMMENT']}</p>
                       
                    </div>
                    ";
                }}
                    ?>
                    </div>
              </div>

      </div>
      <!---------end of col md 4------->
      <div class="col-md-4 two">
        <div class="middle-container">

                <div class="profile block neuro"> <!-- PROFILE (MIDDLE-CONTAINER) -->
                    <a class="add-button" href="#28"><span class="icon entypo-plus scnd-font-color"></span></a>
                    <div class="profile-picture big-profile-picture neuro clear">
                        <img width="150px" alt="Anne Hathaway picture" src="http://upload.wikimedia.org/wikipedia/commons/e/e1/Anne_Hathaway_Face.jpg" >
                    </div>
                    <h1 class="user-name"><?php echo $row['UNAME']?></h1>
                    <div class="profile-description">
                        <p class="scnd-font-color">My Hobby </p>
                       <div class="followcount">
                           <div class="countfitem">
                               <img src="images/diamond.png">
                           </div>
                           <div class="countfitem">
                               <p>Diamond <sup>1M Follower</sup></p>
                           </div>
                       </div>
                       <!------end of follow count--->
                       <div class="followcount">
                           <div class="countfitem">
                               <img src="images/diamond.png">
                           </div>
                           <div class="countfitem">
                               <p>Diamond <sup>1M Posts </sup></p>
                           </div>
                       </div>
                       <!------end of follow count--->
                    </div>

                      <div class="flexbx profile-options horizontal-list">
                        <div class="flexitem">
                          <a class="comments" href="#40"><p><span class="icon fontawesome-comment-alt scnd-font-color"></span>23</p></a>
                        </div>
                        <!--end of flex item--->

                        <div class="flexitem centerflex">
                          <a class="views" href="#41"><p><span class="icon fontawesome-eye-open scnd-font-color"></span>841</p></a>
                        </div>
                        <!--end of flex item--->

                        <div class="flexitem">
                          <a class="likes" href="#42"><p><span class="icon fontawesome-heart-empty scnd-font-color"></span>49</p></a>
                        </div>
                        <!--end of flex item--->
                      </div>

                   
                </div>
                <div class="processchar">
<?php 
          $sqlrankcount="SELECT RANK1,RANK2,RANK3 sum(RANK1 + RANK2 + RANK3 ) as Total from rank group by RID";
          echo $sqlrankcount;
        $resrankcount=$db->query($sqlrankcount);
        if($resrankcount->num_rows>0)
        {
            $rowrankcount=$resrankcount->fetch_assoc();
        }
        else
        {
          
        }
        ?>

                    <h2>My Votings</h2>
                    <div class="progress">
                  <div class="progress-bar progress-bar-striped progress-bar-animated bg-success" role="progressbar" style="width: 80%" aria-valuenow="10" aria-valuemin="0" aria-valuemax="100"></div>

                </div><a href="">
                <p>Total:

                  <?php   
                $sql = "SELECT * FROM rank WHERE UID='".$id."'";
            
            if ($result = mysqli_query($db, $sql)) {
            
                // Return the number of rows in result set
                $rowcount = mysqli_num_rows( $result );
                
                // Display result
                printf(" %d\n", $rowcount);
             }
             else {
                 echo "0";
                 }
             ?> Votes</p></a>

                </div>
                <!-----end of process---->
                 <ul class="social block"> <!-- SOCIAL (MIDDLE-CONTAINER) -->
                    <li><a href="#50"><div class="facebook icon"><span class="zocial-facebook"></span></div><h2 class="facebook titular">SHARE TO FACEBOOK</h2></li></a>
                    <li><a href="#51"><div class="twitter icon"><span class="zocial-twitter"></span></div><h2 class="twitter titular">SHARE TO TWITTER</h2></li></a>
                    <li><a href="#52"><div class="googleplus icon"><span class="zocial-googleplus"></span></div><h2 class="googleplus titular">SHARE TO GOOGLE+</h2></li></a>
                </ul>
      </div>
    

  </div>
      <!--------end of col md- 4 second----->

      <div class="col-md-4 three ">
         <div class="calendar-day block neuro "> <!-- CALENDAR DAY (RIGHT-CONTAINER) -->
                    <div class="arrow-btn-container">
                       
                        <h2 class="titular">WEDNESDAY</h2>
                       
                    </div>
                        <p class="the-day"><?php
                    echo  date('d');
                   
                    ?></p>
                        <a class="primbtn" href="post.php">ADD POSTS</a>
                </div>
                 <div class="tweets block neuro"> <!-- TWEETS (MIDDLE-CONTAINER) -->
                    <h2 class="titular"><span class="icon"><i class="fas fa-address-card"></i></span>Recent Posts</h2>
                    <?php 
               $slpost="SELECT * FROM post ORDER BY PID DESC LIMIT 3";
              $rpost=$db->query($slpost);
                if($rpost->num_rows>0)
                  {
                   
                    while($ropost=$rpost->fetch_assoc())
                    {
                      echo "

                    <div class='tweet first'>
                        <p>{$ropost['PTITLE']}</p>
                        <p>{$ropost['PDESCRIPTION']}</p>
                       
                    </div>
                    ";
                }}
                    ?>
                   

                    
                </div> 
               
            </div>
      </div>
      <!--------end of col md- 4 third----->
    </div>
    <!----end of row------>
  </div>
</section>
<!--------end of main content-------->
<section id="rating">
    

<section id="addnew">
  <div class="container">
    <div class="row">
      <div class="col-md-8">
        <div class="message">
          <a href="#" data-bs-toggle="modal" data-bs-target="#staticBackdrop" class="boxa">
          <div class="box">
            <i class="fas fa-plus"></i>
           </div>
           <!-------end of box------>
        </a>

        <div class="modelboot">
          <!-- Scrollable modal -->


<!-- Modal -->
<div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <div class="title_container">
      <h2 class="completereg">Share Your rating</h2>
          </div>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
       <section id="postform">
  <div class="hoverpass">
 <div class="form_wrapper">
  <div class="form_container">
        <div class="row clearfix">

      <div class="">
       <?php 
          $sqlrank="SELECT * FROM rank WHERE UID='".$id."' and RUID= '".$_SESSION['UID']."'";
          echo $sqlrank;
        $resrank=$db->query($sqlrank);
        if($resrank->num_rows>0)
        {
            $rowrank=$resrank->fetch_assoc();
        }
        else
        {
          
        }
 
 if (isset($_POST["submitrank"]))
  {
 if($resrank->num_rows>0)
        {
            $sqrank="update rank set RANK1='{$_POST["rank1"]}',RANK2='{$_POST["rank2"]}',RANK3='{$_POST["rank3"]}' WHERE UID='".$id."' and RUID= '".$_SESSION['UID']."'";
         echo $sqrank;
         
                           
                            if($db->query($sqrank))
                            {
                             
                                echo '<script>alert("Success")</script>';
                              

                                  $s="SELECT * FROM rank  WHERE UID='".$id."'";

                                $res=$db->query($s);
                                if($res->num_rows>0)
                                {
                                    $rank1=0;
                                    $rank2=0;
                                    $rank3=0;
                                    $overrank=0;
                                    $i=0;

                                    while($r=$res->fetch_assoc())
                                    {  
                                        $i++;
                                     $rank1 += $r['RANK1']; 
                                     $rank2 += $r['RANK2']; 
                                     $rank3 += $r['RANK3']; 
                                     
                                    }
                                   
                                      
                                        $overrank = $rank1 + $rank2 + $rank3;
                                        $overrank = $overrank / ($i * 3);
                                       

                                  $sqb="update user set UPRANK='{$overrank}',UNPRANK='{$i}' where UID='".$id."'";
                                  echo $sqb;
          
       
         
                           
                            if($db->query($sqb))
                            {
                             
                                echo '<script>alert("Updated.")</script>';
                                echo "<script>window.open('home.php','_self');</script>";
                            }
                            else
                            {
                                echo '<script>alert("Sorry! Cant Update Your Work")</script>';
                               // echo "<script>window.open('tasks.php','_self');</script>";
                            }
                            

                                }
                                else
                                {
                                    echo "No Record Found";
                                }
                            //end of rank update
                            }
                            else
                            {
                                echo '<script>alert("Please Try Again")</script>';
                               // echo "<script>window.open('tasks.php','_self');</script>";
                            }
                              
        }
        else
        {
          echo '<script>alert("dd")</script>';
          $sqinsertrank="insert into rank (RUID,UID,RANK1,RANK2,RANK3) values('{$_SESSION["UID"]}','{$_GET["id"]}','{$_POST["rank1"]}','{$_POST["rank2"]}','{$_POST["rank3"]}')";
                            

                             if($db->query($sqinsertrank))
                            {
                             
                                echo '<script>alert("Ranking Success")</script>';
                            }
                            else
                            {
                                echo "<div class='error'>Insert Failed..</div>";
                            }
        }




       
                        }
                        
                    ?>
                    <form method="post" action="<?php echo $_SERVER["PHP_SELF"]."?id=".$_GET['id'];?>">
          
           <label>Did You Refer?</label>
          <div class="input_field">
             <p id="slidervalue1" class="slidervalues"></p>
           <span><i class="fas fa-user-tie"></i></span>
            <input type="range" min="0" max="100" value="<?php echo $rowrank['RANK1']?>" class="slider" id="myRange1" name="rank1" />
          </div>
          <br>
          <!---end of slider---->
          <label>Was the Content Helpful?</label>
          <div class="input_field">
             <p id="slidervalue2" class="slidervalues"></p>
           <span><i class="fas fa-user-tie"></i></span>
            <input  name="rank2"  type="range" min="0" max="100"  value="<?php echo $rowrank['RANK2']?>" class="slider" id="myRange2" />
          </div>
          <br>
          <!---end of slider---->
          <label>Your Overall Rating?</label>
          <div class="input_field">
             <p id="slidervalue3" class="slidervalues"></p>
           <span><i class="fas fa-user-tie"></i></span>
            <input  name="rank3"  type="range" min="0" max="100"  class="slider" id="myRange3"  value="<?php echo $rowrank['RANK3']?>"/>
          </div>
          <br>
          <!---end of slider---->

                  
     
          <input class="primbtn" name="submitrank" type="submit" value="Rank Now" />
        </form>
      </div>
    </div>
  </div>
  </div>
</div>
<!------ending all--->
</section></div></div></div></div></div></div></div></div></div>
</section>
</section>
<!------end of rating---->
     <?php include 'footer.php';?>
    </body>


                    <script>
          var slider1 = document.getElementById("myRange1");
          var output1 = document.getElementById("slidervalue1");
          output1.innerHTML = slider1.value;

          slider1.oninput = function() {
            output1.innerHTML = this.value;
          }
          </script>

                    <script>
          var slider2 = document.getElementById("myRange2");
          var output2 = document.getElementById("slidervalue2");
          output2.innerHTML = slider2.value;

          slider2.oninput = function() {
            output2.innerHTML = this.value;
          }
          </script>
                  <script>
          var slider3 = document.getElementById("myRange3");
          var output3 = document.getElementById("slidervalue3");
          output3.innerHTML = slider3.value;

          slider3.oninput = function() {
            output3.innerHTML = this.value;
          }
          </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-p34f1UUtsS3wqzfto5wAAmdvj+osOnFyQFpp4Ua3gs/ZVWx6oOypYoCJhGGScy+8" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.min.js" integrity="sha384-lpyLfhYuitXl2zRZ5Bn2fqnhNAKOAaM/0Kr9laMspuaMiZfGmfwRNFh8HlMy49eQ" crossorigin="anonymous"></script>
    -->
  </body>
</html>
