



<section id="footer">
    <!-- Site footer -->
    <footer class="site-footer">
      <div class="container">
        <div class="row">
          <div class="col-sm-12 col-md-6">
            <h6>About</h6>
            <p class="text-justify">my domain.com Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
          </div>

          <div class="col-xs-6 col-md-3">
            <h6>Categories</h6>
            <ul class="footer-links">
              <li><a href="#"><i class="fas fa-caret-right"></i> Login</a></li>
              <li><a href="#"><i class="fas fa-caret-right"></i> Logout</a></li>
              <li><a href="#"><i class="fas fa-caret-right"></i> My Profile</a></li>
              <li><a href="#"><i class="fas fa-caret-right"></i> Add Friends</a></li>
                        
              
            </ul>
          </div>

          <div class="col-xs-6 col-md-3">
            <h6>Quick Links</h6>
             <ul class="footer-links">
              <li><a href="#"><i class="fas fa-caret-right"></i> T&C</a></li>
              <li><a href="#"><i class="fas fa-caret-right"></i> Privacy Policy</a></li>
              <li><a href="#"><i class="fas fa-caret-right"></i> About</a></li>
              <li><a href="#"><i class="fas fa-caret-right"></i> Contact</a></li>
                         
              
            </ul>
          </div>
        </div>
        <hr>
      </div>
      <div class="container">
        <div class="row">
          <div class="col-md-8 col-sm-6 col-xs-12">
            <p class="copyright-text">Developed By
         <a href="https://www.salesqueen.in" class="developer">Salesqueen Software Solutions</a>
            </p>
          </div>

          <div class="col-md-4 col-sm-6 col-xs-12">
            <ul class="social-icons">
              <li><a class="facebook" href="#"><i class="fab fa-facebook-f"></i></a></li>
              <li><a class="facebook" href="#"><i class="fab fa-twitter"></i></a></li>
              <li><a class="facebook" href="#"><i class="fab fa-linkedin-in"></i></a></li>
              <li><a class="facebook" href="#"><i class="fab fa-youtube"></i></a></li>   
            </ul>
          </div>
        </div>
      </div>
</footer>
</section>

