<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/board.css">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-wEmeIV1mKuiNpC+IOBjI7aAzPcEZeedi5yW5f2yOq55WWLwNGmvvx4Um1vskeMj0" crossorigin="anonymous">
<!-- Custom styles for this page -->
   
    <title>Post Page</title>
  </head>
  <body>
<?php include 'header.php';?>

 <section id="board">
   <div class="container">
    <div class="tableranks">
        
      <h1 class="ranktab">Ranking Table <br><span> ( Followers & Posts )</span>
        </h1>
<div class="ranktabdiv"></div>
      <div class="row formbot">
        
        <div class="col-md-4"></div>
        <div class="col-md-4">
          <form>
              <div class="commentbox">
            <input type="text" id="myInputform1" onkeyup="searchtable()" placeholder="Search for Rank.." title="Type in a name"class="form-control">
            <button><i class="fas fa-search"></i></button>
          </div>
            </form>
        </div>
        <!----end of col--->
        <div class="col-md-4"></div>
      </div>
      <!----end of row---->



<div class="tablecover">
<table id="myTableform1" class="table table-striped">
  <thead>
     <th>S.No</th>
        <th >Rank</th>
        <th>Reach</th>
  </thead>
  <tr>
     <td>1</td>
     <td>Begineer</td>
    <td>0 - 1K</td>
    
    </tr>
    <tr>
     <td>2</td>
      <td>Bronze</td>
    <td>1K - 10K</td>
   
    </tr>
    <tr>
     <td>3</td>
     <td>Silver</td>
    <td>10K - 50K</td>
    
    </tr>
    <tr>
     <td>4</td>
     <td>Gold</td>
    <td>50K - 100K</td>
    
    </tr>
    <tr>
     <td>5</td>
       <td>Platinum</td>
    <td>100K - 500K</td>
  
    </tr>
    <tr>
     <td>6</td>
     <td>Diamond</td>
    <td>500K to 1M</td>
    
    </tr>
 
  <tr>
     <td>7</td>
     <td>Master</td>
    <td>Greater 1M</td>
    
    </tr>
 
 
  
</table>
    </div>
    <!--------end of table ranks--->
     </div>
     <!-----end of table cover----->
   </div>
 </section>
 <!-----end of board----->
<?php include 'footer.php';?>

<script>
function searchtable() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInputform1");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTableform1");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[1];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-p34f1UUtsS3wqzfto5wAAmdvj+osOnFyQFpp4Ua3gs/ZVWx6oOypYoCJhGGScy+8" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.min.js" integrity="sha384-lpyLfhYuitXl2zRZ5Bn2fqnhNAKOAaM/0Kr9laMspuaMiZfGmfwRNFh8HlMy49eQ" crossorigin="anonymous"></script>
    -->
  </body>
</html>