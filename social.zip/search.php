<?php
error_reporting(0);
$conn = mysqli_connect("localhost","root","","hobby");
if(count($_POST)>0) {
$roll_no=$_POST[roll_no];
$result = mysqli_query($conn,"SELECT * FROM user where UNAME like '%$roll_no%' ");
}
?>
<!DOCTYPE html>
<html>
<head>
<title> Retrive data</title>
<style>
table, th, td {
    border: 1px solid black;
}
</style>
</head>
<body>
<table>
<tr>
<td>Name</td>

</tr>
<?php
$i=0;
while($row = mysqli_fetch_array($result)) {
?>
<tr>
<td><?php echo $row["UNAME"]; ?></td>
</tr>
<?php
$i++;
}
?>
</table>
</body>
</html>