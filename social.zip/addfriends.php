<?php
	include"database.php";
	session_start();
	 $id=$_GET['id'];
$sq="insert into friends(FAID,FBID) values('{$_SESSION["UID"]}','{$_GET["id"]}')";
                            if($db->query($sq))
                            {
                             
                              
                            }
                            else
                            {
                                echo "<div class='Error, Try Again'>Insert Failed..</div>";
                            }

	
	echo "<script>window.open('friends.php?mes=Data Deleted.','_self');</script>"
?>