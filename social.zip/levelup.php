<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/levelup.css">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-wEmeIV1mKuiNpC+IOBjI7aAzPcEZeedi5yW5f2yOq55WWLwNGmvvx4Um1vskeMj0" crossorigin="anonymous">
<!-- Custom styles for this page -->
   s
    <title>Frequently Asked Questions</title>
  </head>
  <body>
<?php include 'header.php';?>

<section id="congrats">
  <!DOCTYPE html>
<html >
  <head>
    <meta charset="UTF-8">
    <title>Remix Challenge</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
<link  rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto" />

    
    <link rel="stylesheet" href="css/normalize.css">

    
        <link rel="stylesheet" href="css/style.css">

    
    
    
  </head>

  <body>

    

<aside class="profile-card">

    <header>
    
        <!-- here’s the avatar -->
        <a href="#">
            <img src="images/cup.png" />
        </a>
        
        <!-- the username -->
        <h1>Vigneshwar Raj</h1>
        
        <!-- and role or location -->
        <h2>Posts: 10001</h2>
        <h2>Hockey</h2>

    
    </header>

    <!-- bit of a bio; who are you? -->
    <div class="profile-bio">
    
        <p>Congradulation! You achieved, Level up from Silver to Crown</p>
    
    </div>


</aside>
<!-- that’s all folks! -->
    
    
    
    
    
  </body>
</html>

</section>
<!----end of congrats----->

<?php include 'footer.php';?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-p34f1UUtsS3wqzfto5wAAmdvj+osOnFyQFpp4Ua3gs/ZVWx6oOypYoCJhGGScy+8" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.min.js" integrity="sha384-lpyLfhYuitXl2zRZ5Bn2fqnhNAKOAaM/0Kr9laMspuaMiZfGmfwRNFh8HlMy49eQ" crossorigin="anonymous"></script>
    -->
  </body>
</html>