<!DOCTYPE html>
<html lang="en">
<head>
  <title>Search Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css">
</head>
<body>
<div class="container">
  <form class="form-inline" method="post" action="">
    <input type="text" name="findfriends" class="form-control" placeholder="Search roll no..">
    <button type="submit" name="save" class="btn btn-primary">Search</button>
  </form>
</div>
</body>
</html>

<?php
error_reporting(0);
$db = mysqli_connect("localhost","root","","hobby");
if(count($_POST)>0) {
$findfriends=$_POST[findfriends];
$result = mysqli_query($db,"SELECT * FROM user where UNAME like '%$findfriends%' ");
}
?>
<!DOCTYPE html>
<html>
<head>
<title> Retrive data</title>
<style>
table, th, td {
    border: 1px solid black;
}
</style>
</head>
<body>
<table>
<tr>
<td>Name</td>

</tr>
<?php
$i=0;
while($row = mysqli_fetch_array($result)) {
?>
<tr>
<td><?php echo $row["UNAME"]; ?></td>
</tr>
<?php
$i++;
}
?>
</table>
</body>
</html>