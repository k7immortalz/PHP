<?php
    include"database.php";
    session_start();
    
    if(!isset($_SESSION["UID"]))
    {
        echo"<script>window.open('index.php?mes=Access Denied...','_self');</script>";
        
    }   
?>

  <?php
error_reporting(0);

if(count($_POST)>0) {
$findfriends=$_POST[findfriends];
$result = mysqli_query($db,"SELECT * FROM post where UID like '%$findfriends%' limit 9");
}
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/post.css">
    <link rel="stylesheet" type="text/css" href="css/addnew.css">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-wEmeIV1mKuiNpC+IOBjI7aAzPcEZeedi5yW5f2yOq55WWLwNGmvvx4Um1vskeMj0" crossorigin="anonymous">

    <title>Post Page</title>
  </head>
  <body>
<?php include 'header.php';?>
  <section id="postpage">
    <div class="container">
      <div class="row postrow">
        <div class="col-md-8 cardcol ">
          <div class="headseperate row">
           
            <div class="col-md-8">
              
           <div class="onhead">
            <h3>Recent Posts</h3>
            <div class="headline"></div>
            <div class="headlineafter"></div>
            <div class="headlineafternext"></div>
            </div>
            </div>
            <!---end of col 6--->
             <div class="col-md-4">
              <div class="commentbox">
                <form>
            <input type="" name="" class="form-control" placeholder="Filter" list="postfil" name="browser" id="browser">

              <datalist id="postfil">
                <option value="Option 1">

                <option value="Option 2">

                <option value="Option 3">

                <option value="Option 4">

                <option value="Option 5">
                
              </datalist>
            <button><i class="fas fa-filter"></i></button>
            
          </div>
          <!--------end of "commentbox---->
              <!----end of form---->
            </div>
            <!---end of col 6--->

               </div>
          <!-----end of head seperate----->
            <!------end of onhead----->
            <div class="filterpost">
              
            </div>
            <!-----end of filter post----->
          
            
         <?php

          echo"<form action='test.php' method='post'>
            dddd
            <input type='submit' value='Edit' name='postcomment'>
        </form>";
$i=0;
while($row = mysqli_fetch_array($result)) {

 
?>
            
          <div class="cardall">
            <div class="  flexpro">
            <div class="flexitpro">
               <div class="profpho" style="background-image:url("{$ro["UPROFILE"]}");">
            
          </div>
            </div>
            <!------end of flexitpro----->

            <div class="flexitpro">
              <h2><span><a href="userhome.php?id={$ro["UID"]}" class="btnr"><?php echo $row["UID"]; ?></a> </span><br> 20 Seconds Ago</h2>
            </div>
            <!------end of flexitpro----->
          </div>
          <!---end of flexpro------>
          <div class="banner">
            <div class="sliderimg">
              <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active " aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active" style="background-image: url("images/Login/fluid-designs.jpg");">
     
    </div>
    <div class="carousel-item"  style="background-image: url("images/Login/fluid-designs.jpg");">
     
    </div>
    <div class="carousel-item"  style="background-image: url("images/Login/fluid-designs.jpg");">
      
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
            </div>
            <!--------end of slider image---->
          </div>
          <!-----end of banner---->
          <div class="tagrelation">
                      
          <ul class="tags">
            <li><a  class="tag">{$ro["PHASHTAG"]}</a></li>
          
          </ul>
          </div>
          <!-----end of tag relation------>
          <div class="happyname">
          <h1>{$ro["PTITLE"]}</h1>
            <p>{$ro["PDESCRIPTION"]}</p>
          </div>
         

          <div class="heartpost">
            <div class="heartitem">
              <i class="far fa-heart"></i>
              <span>10k</span>
            </div>
            <!------end of heartitem-------->
             <div class="heartitem">
              <i class="far fa-comment"></i>
              <span>105556</span>
            </div>
            <!------end of heartitem-------->
             <div class="heartitem">
             <i class="fas fa-paperclip"></i>
              <span>Tag</span>
            </div>
            <!------end of heartitem-------->
             <div class="heartitem">
             <i class="fas fa-share"></i>
              <span>Share</span>
            </div>
            <!------end of heartitem-------->
             <div class="heartitem">
           <i class="far fa-flag"></i>
              <span>Report</span>
            </div>
            <!------end of heartitem-------->

          </div>
         

          <!------end of heartpost----->

<button  class="accordioncomment">Show Comments</button>
<div class="panelcomment">
  
 <div class="flexprocomment">
            
            <div class="flexitprocomment">
               <div class="profphocomment" style="background-image:url("images/login/fluid-designs.jpg")";>
            
          </div>
            </div>
   <div class="flexitprocomment">
              <h2><span>My namddddde </span><br> 20 Seconds Ago</h2>
            </div>
            <!------end of flexitpro----->
          </div>
          <p>This is the para graph this is the para graphthis is the paragraphthis is the paragrav phthis is the paragraph this is the para graph this is the para graphthis is the paragraphthis is the paragrav phthis is the paragraph this is the para graph this is the para graphthis is the paragraphthis is the paragrav phthis is the paragraph this is the para graph this is the para graphthis is the paragraphthis is the paragrav phthis is the paragraphx</p>
          <div class="linecomment"></div>
          <!---end of flexprocomment------>
          <div class="flexprocomment">
            
            <div class="flexitprocomment">
               <div class="profphocomment" style="background-image:url("images/login/fluid-designs.jpg")";>
            
          </div>
            </div>
            <!------end of flexitpro----->
            <div class="flexitprocomment">
              <h2><span>My name </span><br> 20 Seconds Ago</h2>
            </div>
            <!------end of flexitpro----->
          </div>
          <p>This is the para graph this is the para graphthis is the paragraphthis is the paragrav phthis is the paragraph this is the para graph this is the para graphthis is the paragraphthis is the paragrav phthis is the paragraph this is the para graph this is the para graphthis is the paragraphthis is the paragrav phthis is the paragraph this is the para graph this is the para graphthis is the paragraphthis is the paragrav phthis is the paragraphx</p>
          <div class="linecomment"></div>
          <!---end of flexprocomment------>


</div>
<!--------end of panelcomment------>
 
          

          <div class="commentbox">
          <form  method="post" action="post1.php">
            <input type="text" name="pccomment" class="form-control" placeholder="Type Your Comment" required>
            <input type="submit" value="submit" name="postcomment">
           
          </div>
          </form>
          <!--------end of "commentbox---->

         </div>
         <!------end of cardall------>
          <?php
$i++;
}
?>
            
                <<?php 
            if(isset($_POST["postcomment"]))
            {
              $pidpost = $ro["PID"];


              $sqcomment="insert into postcomment(PID,PUID,PCCOMMENT) values('{$pidpost}','{$_SESSION["UID"]}','{$_POST["pccomment"]}')";
              echo $sqcomment;
             
              if($db->query($sqcomment))
              {
                echo "<script>window.open('post.php','_self');</script>";
              }
              else
              {
                  echo '<script>alert("Please Try Again")</script>';
              }
              
            }
            
          ?>
            <!------end of flexitpro----->
         
            <!------end of flexitpro----->
            
         <div class="loadall">Load More</div>

        </div>
        <!------end of col -8---->


        <div class="col-md-4  ">
          <div class="findfriends">
            <div class="onhead">
            <h3>Find Friends</h3>
            <div class="headline"></div>
            <div class="headlineafter"></div>
            <div class="headlineafternext"></div>
            </div>
            <!------end of onhead----->
            <form>
              <div class="commentbox">
            <input type="" name="" class="form-control" placeholder="Search Here">
            <button><i class="fas fa-search"></i></button>
          </div>
            </form>
            <!-----start of friends list------>
            <div class="gaponlin"></div>
            <div class="flexpro relativeadd">
            
            <div class="flexitpro">
               <div class="profpho" style="background-image:url('images/login/fluid-designs.jpg')";>
            
          </div>
            </div>
            <!------end of flexitpro----->
              <div class="flexitpro">
                <h2><span>My name </span><br> My favourite</h2>
              </div>
            <!------end of flexitpro----->
            <div class=" absoluteprofadd">
               <i class="fas fa-user-plus"></i>
              </div>
            <!------end of flexitpro----->
              <div class="profdiv"></div>
          </div>
          <!---end of flexpro------>  
            <div class="flexpro relativeadd">
            
            <div class="flexitpro">
               <div class="profpho" style="background-image:url('images/login/fluid-designs.jpg')";>
            
          </div>
            </div>
            <!------end of flexitpro----->
              <div class="flexitpro">
                <h2><span>My name </span><br> My favourite</h2>
              </div>
            <!------end of flexitpro----->
            <div class=" absoluteprofadd">
               <i class="fas fa-user-plus"></i>
              </div>
            <!------end of flexitpro----->
              <div class="profdiv"></div>
          </div>
          <!---end of flexpro------>  
            <div class="flexpro relativeadd">
            
            <div class="flexitpro">
               <div class="profpho" style="background-image:url('images/login/fluid-designs.jpg')";>
            
          </div>
            </div>
            <!------end of flexitpro----->
              <div class="flexitpro">
                <h2><span>My name </span><br> My favourite</h2>
              </div>
            <!------end of flexitpro----->
            <div class=" absoluteprofadd">
               <i class="fas fa-user-plus"></i>
              </div>
            <!------end of flexitpro----->
              <div class="profdiv"></div>
          </div>
          <!---end of flexpro------>  
            <div class="flexpro relativeadd">
            
            <div class="flexitpro">
               <div class="profpho" style="background-image:url('images/login/fluid-designs.jpg')";>
            
          </div>
            </div>
            <!------end of flexitpro----->
              <div class="flexitpro">
                <h2><span>My name </span><br> My favourite</h2>
              </div>
            <!------end of flexitpro----->
            <div class=" absoluteprofadd">
               <i class="fas fa-user-plus"></i>
              </div>
            <!------end of flexitpro----->
              <div class="profdiv"></div>
          </div>
          <!---end of flexpro------>  
        
          </div>
          <!-------end of find friends---->
          <div class="online">
                <div class="onhead">
                     <h3>Friends Online</h3>
                    <div class="headline"></div>
                    <div class="headlineafter"></div>
                    <div class="headlineafternext"></div>
                </div>
            <!------end of onhead----->

             <div class="flexpro relativeadd">
            
            <div class="flexitpro">
               <div class="profpho" style="background-image:url('images/login/fluid-designs.jpg')";>
            
          </div>
            </div>
            <!------end of flexitpro----->

            <div class="flexitpro">
              <h2><span>My name </span><br> My favourite</h2>
            </div>
            <!------end of flexitpro----->
            <div class=" absoluteprofadd">
               <i class="fas fa-circle absoluteprofaddi"></i>
              </div>
            <!------end of flexitpro----->
            <div class="profdiv"></div>
          </div>
          <!---end of flexpro------>
           <div class="flexpro relativeadd">
            
            <div class="flexitpro">
               <div class="profpho" style="background-image:url('images/login/fluid-designs.jpg')";>
            
          </div>
            </div>
            <!------end of flexitpro----->

            <div class="flexitpro">
              <h2><span>My name </span><br> My favourite</h2>
            </div>
            <!------end of flexitpro----->
            <div class=" absoluteprofadd">
               <i class="fas fa-circle absoluteprofaddi"></i>
              </div>
            <!------end of flexitpro----->
            <div class="profdiv"></div>
          </div>
          <!---end of flexpro------>
           <div class="flexpro relativeadd">
            
            <div class="flexitpro">
               <div class="profpho" style="background-image:url('images/login/fluid-designs.jpg')";>
            
          </div>
            </div>
            <!------end of flexitpro----->

            <div class="flexitpro">
              <h2><span>My name </span><br> My favourite</h2>
            </div>
            <!------end of flexitpro----->
            <div class=" absoluteprofadd">
               <i class="fas fa-circle absoluteprofaddi"></i>
              </div>
            <!------end of flexitpro----->
            <div class="profdiv"></div>
          </div>
          <!---end of flexpro------>
           <div class="flexpro relativeadd">
            
            <div class="flexitpro">
               <div class="profpho" style="background-image:url('images/login/fluid-designs.jpg')";>
            
          </div>
            </div>
            <!------end of flexitpro----->

            <div class="flexitpro">
              <h2><span>My name </span><br> My favourite</h2>
            </div>
            <!------end of flexitpro----->
            <div class=" absoluteprofadd">
               <i class="fas fa-circle absoluteprofaddi"></i>
              </div>
            <!------end of flexitpro----->
            <div class="profdiv"></div>
          </div>
          <!---end of flexpro------>
          <div class="flexpro relativeadd">
            
            <div class="flexitpro">
               <div class="profpho" style="background-image:url('images/login/fluid-designs.jpg')";>
            
          </div>
            </div>
            <!------end of flexitpro----->

            <div class="flexitpro">
              <h2><span>My name </span><br> My favourite</h2>
            </div>
            <!------end of flexitpro----->
            <div class=" absoluteprofadd">
               <i class="fas fa-circle absoluteprofaddi"></i>
              </div>
            <!------end of flexitpro----->
            <div class="profdiv"></div>
          </div>
          <!---end of flexpro------>
           <div class="flexpro relativeadd">
            
            <div class="flexitpro">
               <div class="profpho" style="background-image:url('images/login/fluid-designs.jpg')";>
            
          </div>
            </div>
            <!------end of flexitpro----->

            <div class="flexitpro">
              <h2><span>My name </span><br> My favourite</h2>
            </div>
            <!------end of flexitpro----->
            <div class=" absoluteprofadd">
               <i class="fas fa-circle absoluteprofaddi"></i>
              </div>
            <!------end of flexitpro----->
            <div class="profdiv"></div>
          </div>
          <!---end of flexpro------>
          
          <div class="flexpro relativeadd">
            
            <div class="flexitpro">
               <div class="profpho" style="background-image:url('images/login/fluid-designs.jpg')";>
            
          </div>
            </div>
            <!------end of flexitpro----->

            <div class="flexitpro">
              <h2><span>My name </span><br> My favourite</h2>
            </div>
            <!------end of flexitpro----->
            <div class=" absoluteprofadd">
               <i class="fas fa-circle absoluteprofaddi"></i>
              </div>
            <!------end of flexitpro----->
            <div class="profdiv"></div>
          </div>
          <!---end of flexpro------>
           <div class="flexpro relativeadd">
            
            <div class="flexitpro">
               <div class="profpho" style="background-image:url('images/login/fluid-designs.jpg')";>
            
          </div>
            </div>
            <!------end of flexitpro----->

            <div class="flexitpro">
              <h2><span>My name </span><br> My favourite</h2>
            </div>
            <!------end of flexitpro----->
            <div class=" absoluteprofadd">
               <i class="fas fa-circle absoluteprofaddi"></i>
              </div>
            <!------end of flexitpro----->
            <div class="profdiv"></div>
          </div>
          <!---end of flexpro------>
          
          <div class="flexpro relativeadd">
            
            <div class="flexitpro">
               <div class="profpho" style="background-image:url('images/login/fluid-designs.jpg')";>
            
          </div>
            </div>
            <!------end of flexitpro----->

            <div class="flexitpro">
              <h2><span>My name </span><br> My favourite</h2>
            </div>
            <!------end of flexitpro----->
            <div class=" absoluteprofadd">
               <i class="fas fa-circle absoluteprofaddi"></i>
              </div>
            <!------end of flexitpro----->
            <div class="profdiv"></div>
          </div>
          <!---end of flexpro------>
           <div class="flexpro relativeadd">
            
            <div class="flexitpro">
               <div class="profpho" style="background-image:url('images/login/fluid-designs.jpg')";>
            
          </div>
            </div>
            <!------end of flexitpro----->

            <div class="flexitpro">
              <h2><span>My name </span><br> My favourite</h2>
            </div>
            <!------end of flexitpro----->
            <div class=" absoluteprofadd">
               <i class="fas fa-circle absoluteprofaddi"></i>
              </div>
            <!------end of flexitpro----->
            <div class="profdiv"></div>
          </div>
          <!---end of flexpro------>
          
          <div class="flexpro relativeadd">
            
            <div class="flexitpro">
               <div class="profpho" style="background-image:url('images/login/fluid-designs.jpg')";>
            
          </div>
            </div>
            <!------end of flexitpro----->

            <div class="flexitpro">
              <h2><span>My name </span><br> My favourite</h2>
            </div>
            <!------end of flexitpro----->
            <div class=" absoluteprofadd">
               <i class="fas fa-circle absoluteprofaddi"></i>
              </div>
            <!------end of flexitpro----->
            <div class="profdiv"></div>
          </div>
          <!---end of flexpro------>
           <div class="flexpro relativeadd">
            
            <div class="flexitpro">
               <div class="profpho" style="background-image:url('images/login/fluid-designs.jpg')";>
            
          </div>
            </div>
            <!------end of flexitpro----->

            <div class="flexitpro">
              <h2><span>My name </span><br> My favourite</h2>
            </div>
            <!------end of flexitpro----->
            <div class=" absoluteprofadd">
               <i class="fas fa-circle absoluteprofaddi"></i>
              </div>
            <!------end of flexitpro----->
            <div class="profdiv"></div>
          </div>
          <!---end of flexpro------>
          

         
          </div>
<!-------online ends------->
        </div>
        <!------end of col -4---->
      </div>
      <!-------end of row----->
    </div>
  </section>
<!----end of post page------>
<section id="mobilefooter">
  <div class="flexbox1">
    <div class="footite">
      <i class="fas fa-plus-square"></i>
    </div>
    <!--------end of foot ite---->
    <div class="footite">
      <i class="fas fa-home"></i>
    </div>
    <!--------end of foot ite---->
    <div class="footite">
      <i class="fas fa-user-alt"></i>
    </div>
    <!--------end of foot ite---->
    <div class="footite">
      <i class="fas fa-comment-dots"></i>
    </div>
    <!--------end of foot ite---->
  </div>
  <!------end of foot flex---->
</section>
<!------end of mobile footer------->

<?php include 'addnew.php';?>
<?php include 'footer.php';?>
<script>
var acc = document.getElementsByClassName("accordioncomment");
var i;

for (i = 0; i < acc.length; i++) {
  acc[i].addEventListener("click", function() {
    this.classList.toggle("activecomment");
    var panelcomment = this.nextElementSibling;
    if (panelcomment.style.display === "block") {
      panelcomment.style.display = "none";
    } else {
      panelcomment.style.display = "block";
    }
  });
}
</script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-p34f1UUtsS3wqzfto5wAAmdvj+osOnFyQFpp4Ua3gs/ZVWx6oOypYoCJhGGScy+8" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.min.js" integrity="sha384-lpyLfhYuitXl2zRZ5Bn2fqnhNAKOAaM/0Kr9laMspuaMiZfGmfwRNFh8HlMy49eQ" crossorigin="anonymous"></script>
    -->
  </body>
</html>
          <?php echo "<form action='test.php' method='post'>
            
            <input type='submit' value='Edit' name='postcomment'>
        </form>";?>;
            