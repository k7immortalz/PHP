<?php
    include"database.php";
    session_start();
    
    if(!isset($_SESSION["UID"]))
    {
        echo"<script>window.open('index.php?mes=Access Denied...','_self');</script>";
        
    }   
?>
  <?php
error_reporting(0);

if(count($_POST)>0) {
$findfriends=$_POST[findfriends];
$result = mysqli_query($db,"SELECT * FROM market where PRNAME like '%$findfriends%' limit 9");
}
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/friends.css">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-wEmeIV1mKuiNpC+IOBjI7aAzPcEZeedi5yW5f2yOq55WWLwNGmvvx4Um1vskeMj0" crossorigin="anonymous">
<!-- Custom styles for this page -->
   
    <title>Post Page</title>
  </head>
  <body>
<?php include 'header.php';?>
<section id="searchrow">
  <div class="conteiner">
    <div class="row">
      <div class="col-md-4">
        
      </div>
      <!-----end of col 4---->
      
      <div class="col-md-4">
          <div class="commentbox">


            <form method="post" action="marketplace.php">
            <input type="text" name="findfriends" required  class="form-control" placeholder="Search Friends" >
                           
            <button type="submit" name="findfriend" ><i class="fas fa-paper-plane"></i></button>
            </form>
  
       

          </div>
          <!--------end of "commentbox---->
      </div>
      <!-----end of col 4---->
      <div class="col-md-4">
        
      </div>
      <!-----end of col 4---->
    </div>
  </div>
  <!-----end of conteiner--->
</section>



<section id="products">
  <div class="container">
    <div class="procard">


       <?php
           
            $s="SELECT * FROM market ORDER BY PRID DESC ";
                                $res=$db->query($s);
                                if($res->num_rows>0)
                                {
                                    $i=0;
                                    while($r=$res->fetch_assoc())
                                    {
                                        $i++;
                                        echo "
                                        	<div class='procarditem'>

									<img src='{$r["PRIMG"]}'>
									<h1>{$r["PRNAME"]}</h1>
									<p>{$r["PRDESCRIPTION"]}</p>
									<h6>Rs.{$r["PRPRICE"]}</h6>
									<a href='tel:+91{$r["PRNUM"]}''><i class='fas fa-phone-volume'></i>Enquire Now</a>
								</div>
								<!--end of procarditem-->


                                        
                                        
                                        ";
                                        
                                    }
                                }
                                else
                                {
                                    echo "No Record Found";
                                }
                            
                            
            
          ?>
    
   
      
    </div>
    <!-----end of card head----->


  </div>
</section>
<!------end of friends section----->
<?php include 'footer.php';?>

<div class="floatlink">
	<a href="viewproducts.php">
	<i class="fas fa-poll-h"></i>
	</a>
	<br>
	<br>
	<a href="addproducts.php">
	<i class="fas fa-plus"></i>
</a>
	
	
</div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-p34f1UUtsS3wqzfto5wAAmdvj+osOnFyQFpp4Ua3gs/ZVWx6oOypYoCJhGGScy+8" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.min.js" integrity="sha384-lpyLfhYuitXl2zRZ5Bn2fqnhNAKOAaM/0Kr9laMspuaMiZfGmfwRNFh8HlMy49eQ" crossorigin="anonymous"></script>
    -->
  </body>
</html>