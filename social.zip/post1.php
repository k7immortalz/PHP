<?php
    include"database.php";
    session_start();
    
    if(!isset($_SESSION["UID"]))
    {
        echo"<script>window.open('index.php?mes=Access Denied...','_self');</script>";
        
    }   
?>

  <?php
error_reporting(0);
if(isset($_POST["limit"], $_POST["start"]))
{
$result = mysqli_query($db,"SELECT * FROM post LIMIT ".$_POST["start"].", ".$_POST["limit"]."");
}
?>
<?php
$i=0;
while($row = mysqli_fetch_array($result)) {
?>
<?php
         
$UIDU = $row["UID"];

$result3 = mysqli_query($db,"SELECT * FROM user WHERE UID='$UIDU'");
while($row3 = mysqli_fetch_array($result3)) {
  if($row3["STSTUS"] == 'Public'){
?>   
          <div class="cardall">
            <div class="  flexpro">
            <div class="flexitpro">

            <?php
$img = $row["UID"];
$result1 = mysqli_query($db,"SELECT UPROFILE FROM user WHERE UID='$img'");
while($row1 = mysqli_fetch_array($result1)) {
?> 
               <div class="profpho" style="background-image:url('<?php echo $row1["UPROFILE"]; ?>');">
         <?php } ?>   
          </div>
            </div>
            <!------end of flexitpro----->

            <div class="flexitpro">
              <h2><span><a href="userhome.php?id=<?php echo $row["UID"]; ?>" class="btnr"><?php echo $row["UID"]; ?></a> </span><br> 20 Seconds Ago</h2>
            </div>
            <!------end of flexitpro----->
          </div>
          <!---end of flexpro------>
         <!----- <div class="banner">
            <div class="sliderimg">
              <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active " aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active" style="background-image: url("images/Login/fluid-designs.jpg");">
     
    </div>
    <div class="carousel-item"  style="background-image: url("images/Login/fluid-designs.jpg");">
     
    </div>
    <div class="carousel-item"  style="background-image: url("images/Login/fluid-designs.jpg");">
      
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
            </div>---->
            <!--------end of slider image---->
          </div>
          <!-----end of banner---->
          <div class="tagrelation">
                      
          <ul class="tags">
            <li><a  class="tag">{$ro["PHASHTAG"]}</a></li>
          
          </ul>
          </div>
          <!-----end of tag relation------>
          <div class="happyname">
          <h1><?php echo $row["PTITLE"]; ?></h1>
            <p><?php echo $row["PDESCRIPTION"]; ?></p>
            
          </div>
         

          <div class="heartpost">
            <div class="heartitem">
              <i class="far fa-heart"></i>
              <span>10k</span>
            </div>
            <!------end of heartitem-------->
             <div class="heartitem">
              <i class="far fa-comment"></i>
              <span>105556</span>
            </div>
            <!------end of heartitem-------->
             <div class="heartitem">
             <i class="fas fa-paperclip"></i>
              <span>Tag</span>
            </div>
            <!------end of heartitem-------->
             <div class="heartitem">
             <i class="fas fa-share"></i>
              <span>Share</span>
            </div>
            <!------end of heartitem-------->
             <div class="heartitem">
           <i class="far fa-flag"></i>
              <span>Report</span>
            </div>
            <!------end of heartitem-------->

          </div>
         

          <!------end of heartpost----->
<?php 
$show = $row["PID"];
?>
<button  class="accordioncomment" id='s<?php echo $row["PID"];?>' onclick="show('s<?php echo $show; ?>');">Show Comments</button>
<div class="panelcomment hide">
<?php
$text1= $row["PID"];
$text2= $_SESSION["UID"];
          $sql1 = "SELECT PCCOMMENT FROM postcomment WHERE PID='$text1'";
$result1 = mysqli_query($db, $sql1);

if (mysqli_num_rows($result1) > 0) {
  // output data of each row
  while($row1 = mysqli_fetch_assoc($result1)) {
      ?>
      <div class="flexprocomment">
            
            <div class="flexitprocomment">
               <div class="profphocomment" style="background-image:url("images/login/fluid-designs.jpg")";>
            
          </div>
            </div>
   <div class="flexitprocomment">
              <h2><span>My namddddde </span><br> 20 Seconds Ago</h2>
            </div>
            <!------end of flexitpro----->
          </div>
          <p><?php echo "<p> " . $row1["PCCOMMENT"]. " </p> ";?></p>
          <div class="linecomment"></div>
      <?php
   
  }
} else {
  echo "0 results";
}
?> 
<?php
          $pid=$row["PID"];
          $uid=$_SESSION["UID"];
          $pinput=$row["PID"];
          ?>
<div id="comment<?php echo $row["PID"]; ?>"> </div>
     
          


</div>
<!--------end of panelcomment------>
 
          

          <div class="commentbox">
          
              
            <input type="text" id="c<?php echo $row["PID"]; ?>" name="postInput" class="form-control" placeholder="Type Your Comment" required>
            <button onclick="getInputValue('<?php echo $pid; ?>','<?php echo $uid; ?>','c<?php echo $pinput; ?>');"><i class="fas fa-paper-plane"></i></button>

          </div>
          
          <!--------end of "commentbox---->

         
         <!------end of cardall------>
          <?php
  }
  else if($row3["STSTUS"] == 'Private'){
    $VR=$_SESSION["UID"];
    $result4 = mysqli_query($db,"SELECT * FROM friends WHERE FAID='$VR'");
while($row4 = mysqli_fetch_array($result4)) {
  if((($row4["FBID"] == $_SESSION["UID"]) && ($row["UID"] == $row4["FAID"]))||($_SESSION["UID"]==$row["UID"])){

?>



    <div class="cardall">
    <div class="  flexpro">
    <div class="flexitpro">

    <?php
$img = $row["UID"];
$result1 = mysqli_query($db,"SELECT UPROFILE FROM user WHERE UID='$img'");
while($row1 = mysqli_fetch_array($result1)) {
?> 
       <div class="profpho" style="background-image:url('<?php echo $row1["UPROFILE"]; ?>');">
 <?php } ?>   
  </div>
    </div>
    <!------end of flexitpro----->

    <div class="flexitpro">
      <h2><span><a href="userhome.php?id=<?php echo $row["UID"]; ?>" class="btnr"><?php echo $row["UID"]; ?></a> </span><br> 20 Seconds Ago</h2>
    </div>
    <!------end of flexitpro----->
  </div>
  <!---end of flexpro------>
 
    <!--------end of slider image---->
  </div>
  <!-----end of banner---->
  <div class="tagrelation">
              
  <ul class="tags">
    <li><a  class="tag">{$row["PHASHTAG"]}</a></li>
  
  </ul>
  </div>
  <!-----end of tag relation------>
  <div class="happyname">
  <h1><?php echo $row["PTITLE"]; ?></h1>
    <p><?php echo $row["PDESCRIPTION"]; ?></p>
    
  </div>
 

  <div class="heartpost">
    <div class="heartitem">
      <i class="far fa-heart"></i>
      <span>10k</span>
    </div>
    <!------end of heartitem-------->
     <div class="heartitem">
      <i class="far fa-comment"></i>
      <span>105556</span>
    </div>
    <!------end of heartitem-------->
     <div class="heartitem">
     <i class="fas fa-paperclip"></i>
      <span>Tag</span>
    </div>
    <!------end of heartitem-------->
     <div class="heartitem">
     <i class="fas fa-share"></i>
      <span>Share</span>
    </div>
    <!------end of heartitem-------->
     <div class="heartitem">
   <i class="far fa-flag"></i>
      <span>Report</span>
    </div>
    <!------end of heartitem-------->

  </div>
 

  <!------end of heartpost----->

<button  class="accordioncomment" id='s<?php echo $row["PID"];?>' onclick="show('s<?php echo $show; ?>');">Show Comments</button>
<div class="panelcomment hide">
<?php
$text1= $row["PID"];
$text2= $_SESSION["UID"];
  $sql1 = "SELECT PCCOMMENT FROM postcomment WHERE PID='$text1'";
$result1 = mysqli_query($db, $sql1);

if (mysqli_num_rows($result1) > 0) {
// output data of each row
while($row1 = mysqli_fetch_assoc($result1)) {
?>
<div class="flexprocomment">
    
    <div class="flexitprocomment">
       <div class="profphocomment" style="background-image:url("images/login/fluid-designs.jpg")";>
    
  </div>
    </div>
<div class="flexitprocomment">
      <h2><span>My namddddde </span><br> 20 Seconds Ago</h2>
    </div>
    <!------end of flexitpro----->
  </div>
  <p><?php echo "<p> " . $row1["PCCOMMENT"]. " </p> ";?></p>
  <div class="linecomment"></div>
<?php

}
} else {
echo "0 results";
}
?> 
<?php
  $pid=$row["PID"];
  $uid=$_SESSION["UID"];
  $pinput=$row["PID"];
  ?>
<div id="comment<?php echo $row["PID"]; ?>"> </div>

  


</div>
<!--------end of panelcomment------>

  

  <div class="commentbox">
  
      
    <input type="text" id="c<?php echo $row["PID"]; ?>" name="postInput" class="form-control" placeholder="Type Your Comment" required>
    <button onclick="getInputValue('<?php echo $pid; ?>','<?php echo $uid; ?>','c<?php echo $pinput; ?>');"><i class="fas fa-paper-plane"></i></button>

  </div>


<?php
  }
}
  }
  }
$i++;
}
?>
            
               
            <!------end of flexitpro----->
         
            <!------end of flexitpro----->
     
            

            <script>
var acc = document.getElementsByClassName("accordioncomment");
var i;

for (i = 0; i < acc.length; i++) {
  acc[i].addEventListener("click", function() {
    this.classList.toggle("activecomment");
    var panelcomment = this.nextElementSibling;
    if (panelcomment.style.display === "block") {
      panelcomment.style.display = "none";
    } else {
      panelcomment.style.display = "block";
    }
  });
}
var count = 1;

function getInputValue(a,b,c){
 na= count++; 
            var inputVal3 = document.getElementById(c).value;
            // Displaying the value
            console.log(a,b,inputVal3);
            $.ajax({
        type: 'POST',
        url: 'comment.php',
         
        data: { PID: a, PUID: b, PCCOMMENT: inputVal3,count2:na },
        success: function(data) {
          var numb = '#comment'+a;
            $(numb).html(data);
        }
    });
    
        }



</script>
        
