<?php
	include"database.php";
	session_start();
	
	$s="delete from friends where FID={$_GET["id"]}";
	$db->query($s);
	echo "<script>window.open('friends.php?mes=Data Deleted.','_self');</script>"
?>