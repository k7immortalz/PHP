<?php
    include"database.php";
    session_start();
    
    if(!isset($_SESSION["UID"]))
    {
        echo"<script>window.open('index.php?mes=Access Denied...','_self');</script>";
        
    }   
?>

 
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/post.css">
    <link rel="stylesheet" type="text/css" href="css/addnew.css">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-wEmeIV1mKuiNpC+IOBjI7aAzPcEZeedi5yW5f2yOq55WWLwNGmvvx4Um1vskeMj0" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
    <title>Post Page</title>
  </head>
  <body>
<?php include 'header.php';?>
  <section id="postpage">
    <div class="container">
      <div class="row postrow">
        <div class="col-md-8 cardcol ">
          <div class="headseperate row">
           
            <div class="col-md-8">
              
           <div class="onhead">
            <h3>Recent Posts</h3>
            <div class="headline"></div>
            <div class="headlineafter"></div>
            <div class="headlineafternext"></div>
            </div>
            </div>
            <!---end of col 6--->
             <div class="col-md-4">
              <div class="commentbox">
                <form>
            <input type="" name="" class="form-control" placeholder="Filter" list="postfil" name="browser" id="browser">

              <datalist id="postfil">
                <option value="Option 1">

                <option value="Option 2">

                <option value="Option 3">

                <option value="Option 4">

                <option value="Option 5">
                
              </datalist>
            <button><i class="fas fa-filter"></i></button>
            
          </div>
          <!--------end of "commentbox---->
              <!----end of form---->
            </div>
            <!---end of col 6--->

               </div>
          <!-----end of head seperate----->
            <!------end of onhead----->
            <div class="filterpost">
              
            </div>
            <!-----end of filter post----->
          
            <div  id="load_data"></div>
   <div class="mt-5" id="load_data_message"></div>
         
        </div>
        <!------end of col -8---->


        <div class="col-md-4  ">
          <div class="findfriends">
            <div class="onhead">
            <h3>Find Friends</h3>
            <div class="headline"></div>
            <div class="headlineafter"></div>
            <div class="headlineafternext"></div>
            </div>
            <!------end of onhead----->
            <form>
              <div class="commentbox">
            <input type="" name="" class="form-control" placeholder="Search Here">
            <button><i class="fas fa-search"></i></button>
          </div>
            </form>
            <!-----start of friends list------>
            <div class="gaponlin"></div>
            <div class="flexpro relativeadd">
            
            <div class="flexitpro">
               <div class="profpho" style="background-image:url('images/login/fluid-designs.jpg')";>
            
          </div>
            </div>
            <!------end of flexitpro----->
              <div class="flexitpro">
                <h2><span>My name </span><br> My favourite</h2>
              </div>
            <!------end of flexitpro----->
            <div class=" absoluteprofadd">
               <i class="fas fa-user-plus"></i>
              </div>
            <!------end of flexitpro----->
              <div class="profdiv"></div>
          </div>
          <!---end of flexpro------>  
            <div class="flexpro relativeadd">
            
            <div class="flexitpro">
               <div class="profpho" style="background-image:url('images/login/fluid-designs.jpg')";>
            
          </div>
            </div>
            <!------end of flexitpro----->
              <div class="flexitpro">
                <h2><span>My name </span><br> My favourite</h2>
              </div>
            <!------end of flexitpro----->
            <div class=" absoluteprofadd">
               <i class="fas fa-user-plus"></i>
              </div>
            <!------end of flexitpro----->
              <div class="profdiv"></div>
          </div>
          <!---end of flexpro------>  
            <div class="flexpro relativeadd">
            
            <div class="flexitpro">
               <div class="profpho" style="background-image:url('images/login/fluid-designs.jpg')";>
            
          </div>
            </div>
            <!------end of flexitpro----->
              <div class="flexitpro">
                <h2><span>My name </span><br> My favourite</h2>
              </div>
            <!------end of flexitpro----->
            <div class=" absoluteprofadd">
               <i class="fas fa-user-plus"></i>
              </div>
            <!------end of flexitpro----->
              <div class="profdiv"></div>
          </div>
          <!---end of flexpro------>  
            <div class="flexpro relativeadd">
            
            <div class="flexitpro">
               <div class="profpho" style="background-image:url('images/login/fluid-designs.jpg')";>
            
          </div>
            </div>
            <!------end of flexitpro----->
              <div class="flexitpro">
                <h2><span>My name </span><br> My favourite</h2>
              </div>
            <!------end of flexitpro----->
            <div class=" absoluteprofadd">
               <i class="fas fa-user-plus"></i>
              </div>
            <!------end of flexitpro----->
              <div class="profdiv"></div>
          </div>
          <!---end of flexpro------>  
        
          </div>
          <!-------end of find friends---->
          <div class="online">
                <div class="onhead">
                     <h3>Friends Online</h3>
                    <div class="headline"></div>
                    <div class="headlineafter"></div>
                    <div class="headlineafternext"></div>
                </div>
            <!------end of onhead----->

             <div class="flexpro relativeadd">
            
            <div class="flexitpro">
               <div class="profpho" style="background-image:url('images/login/fluid-designs.jpg')";>
            
          </div>
            </div>
            <!------end of flexitpro----->

            <div class="flexitpro">
              <h2><span>My name </span><br> My favourite</h2>
            </div>
            <!------end of flexitpro----->
            <div class=" absoluteprofadd">
               <i class="fas fa-circle absoluteprofaddi"></i>
              </div>
            <!------end of flexitpro----->
            <div class="profdiv"></div>
          </div>
          <!---end of flexpro------>
           <div class="flexpro relativeadd">
            
            <div class="flexitpro">
               <div class="profpho" style="background-image:url('images/login/fluid-designs.jpg')";>
            
          </div>
            </div>
            <!------end of flexitpro----->

            <div class="flexitpro">
              <h2><span>My name </span><br> My favourite</h2>
            </div>
            <!------end of flexitpro----->
            <div class=" absoluteprofadd">
               <i class="fas fa-circle absoluteprofaddi"></i>
              </div>
            <!------end of flexitpro----->
            <div class="profdiv"></div>
          </div>
          <!---end of flexpro------>
           <div class="flexpro relativeadd">
            
            <div class="flexitpro">
               <div class="profpho" style="background-image:url('images/login/fluid-designs.jpg')";>
            
          </div>
            </div>
            <!------end of flexitpro----->

            <div class="flexitpro">
              <h2><span>My name </span><br> My favourite</h2>
            </div>
            <!------end of flexitpro----->
            <div class=" absoluteprofadd">
               <i class="fas fa-circle absoluteprofaddi"></i>
              </div>
            <!------end of flexitpro----->
            <div class="profdiv"></div>
          </div>
          <!---end of flexpro------>
           <div class="flexpro relativeadd">
            
            <div class="flexitpro">
               <div class="profpho" style="background-image:url('images/login/fluid-designs.jpg')";>
            
          </div>
            </div>
            <!------end of flexitpro----->

            <div class="flexitpro">
              <h2><span>My name </span><br> My favourite</h2>
            </div>
            <!------end of flexitpro----->
            <div class=" absoluteprofadd">
               <i class="fas fa-circle absoluteprofaddi"></i>
              </div>
            <!------end of flexitpro----->
            <div class="profdiv"></div>
          </div>
          <!---end of flexpro------>
          <div class="flexpro relativeadd">
            
            <div class="flexitpro">
               <div class="profpho" style="background-image:url('images/login/fluid-designs.jpg')";>
            
          </div>
            </div>
            <!------end of flexitpro----->

            <div class="flexitpro">
              <h2><span>My name </span><br> My favourite</h2>
            </div>
            <!------end of flexitpro----->
            <div class=" absoluteprofadd">
               <i class="fas fa-circle absoluteprofaddi"></i>
              </div>
            <!------end of flexitpro----->
            <div class="profdiv"></div>
          </div>
          <!---end of flexpro------>
           <div class="flexpro relativeadd">
            
            <div class="flexitpro">
               <div class="profpho" style="background-image:url('images/login/fluid-designs.jpg')";>
            
          </div>
            </div>
            <!------end of flexitpro----->

            <div class="flexitpro">
              <h2><span>My name </span><br> My favourite</h2>
            </div>
            <!------end of flexitpro----->
            <div class=" absoluteprofadd">
               <i class="fas fa-circle absoluteprofaddi"></i>
              </div>
            <!------end of flexitpro----->
            <div class="profdiv"></div>
          </div>
          <!---end of flexpro------>
          
          <div class="flexpro relativeadd">
            
            <div class="flexitpro">
               <div class="profpho" style="background-image:url('images/login/fluid-designs.jpg')";>
            
          </div>
            </div>
            <!------end of flexitpro----->

            <div class="flexitpro">
              <h2><span>My name </span><br> My favourite</h2>
            </div>
            <!------end of flexitpro----->
            <div class=" absoluteprofadd">
               <i class="fas fa-circle absoluteprofaddi"></i>
              </div>
            <!------end of flexitpro----->
            <div class="profdiv"></div>
          </div>
          <!---end of flexpro------>
           <div class="flexpro relativeadd">
            
            <div class="flexitpro">
               <div class="profpho" style="background-image:url('images/login/fluid-designs.jpg')";>
            
          </div>
            </div>
            <!------end of flexitpro----->

            <div class="flexitpro">
              <h2><span>My name </span><br> My favourite</h2>
            </div>
            <!------end of flexitpro----->
            <div class=" absoluteprofadd">
               <i class="fas fa-circle absoluteprofaddi"></i>
              </div>
            <!------end of flexitpro----->
            <div class="profdiv"></div>
          </div>
          <!---end of flexpro------>
          
          <div class="flexpro relativeadd">
            
            <div class="flexitpro">
               <div class="profpho" style="background-image:url('images/login/fluid-designs.jpg')";>
            
          </div>
            </div>
            <!------end of flexitpro----->

            <div class="flexitpro">
              <h2><span>My name </span><br> My favourite</h2>
            </div>
            <!------end of flexitpro----->
            <div class=" absoluteprofadd">
               <i class="fas fa-circle absoluteprofaddi"></i>
              </div>
            <!------end of flexitpro----->
            <div class="profdiv"></div>
          </div>
          <!---end of flexpro------>
           <div class="flexpro relativeadd">
            
            <div class="flexitpro">
               <div class="profpho" style="background-image:url('images/login/fluid-designs.jpg')";>
            
          </div>
            </div>
            <!------end of flexitpro----->

            <div class="flexitpro">
              <h2><span>My name </span><br> My favourite</h2>
            </div>
            <!------end of flexitpro----->
            <div class=" absoluteprofadd">
               <i class="fas fa-circle absoluteprofaddi"></i>
              </div>
            <!------end of flexitpro----->
            <div class="profdiv"></div>
          </div>
          <!---end of flexpro------>
          
          <div class="flexpro relativeadd">
            
            <div class="flexitpro">
               <div class="profpho" style="background-image:url('images/login/fluid-designs.jpg')";>
            
          </div>
            </div>
            <!------end of flexitpro----->

            <div class="flexitpro">
              <h2><span>My name </span><br> My favourite</h2>
            </div>
            <!------end of flexitpro----->
            <div class=" absoluteprofadd">
               <i class="fas fa-circle absoluteprofaddi"></i>
              </div>
            <!------end of flexitpro----->
            <div class="profdiv"></div>
          </div>
          <!---end of flexpro------>
           <div class="flexpro relativeadd">
            
            <div class="flexitpro">
               <div class="profpho" style="background-image:url('images/login/fluid-designs.jpg')";>
            
          </div>
            </div>
            <!------end of flexitpro----->

            <div class="flexitpro">
              <h2><span>My name </span><br> My favourite</h2>
            </div>
            <!------end of flexitpro----->
            <div class=" absoluteprofadd">
               <i class="fas fa-circle absoluteprofaddi"></i>
              </div>
            <!------end of flexitpro----->
            <div class="profdiv"></div>
          </div>
          <!---end of flexpro------>
          

         
          </div>
<!-------online ends------->
        </div>
        <!------end of col -4---->
      </div>
      <!-------end of row----->
    </div>
  </section>
<!----end of post page------>
<section id="mobilefooter">
  <div class="flexbox1">
    <div class="footite">
      <i class="fas fa-plus-square"></i>
    </div>
    <!--------end of foot ite---->
    <div class="footite">
      <i class="fas fa-home"></i>
    </div>
    <!--------end of foot ite---->
    <div class="footite">
      <i class="fas fa-user-alt"></i>
    </div>
    <!--------end of foot ite---->
    <div class="footite">
      <i class="fas fa-comment-dots"></i>
    </div>
    <!--------end of foot ite---->
  </div>
  <!------end of foot flex---->
</section>
<!------end of mobile footer------->

<?php include 'addnew.php';?>
<?php include 'footer.php';?>
<script>
var acc = document.getElementsByClassName("accordioncomment");
var i;

for (i = 0; i < acc.length; i++) {
  acc[i].addEventListener("click", function() {
    this.classList.toggle("activecomment");
    var panelcomment = this.nextElementSibling;
    if (panelcomment.style.display === "block") {
      panelcomment.style.display = "none";
    } else {
      panelcomment.style.display = "block";
    }
  });
}






</script>
<script>

$(document).ready(function(){
 
 var limit = 7;
 var start = 0;
 var action = 'inactive';
 function load_country_data(limit, start)
 {
  $.ajax({
   url:"post1.php",
   method:"POST",
   data:{limit:limit, start:start},
   cache:false,
   success:function(data)
   {
    $('#load_data').append(data);
    if(data == '')
    {
     $('#load_data_message').html("<button type='button' class='btn btn-info'>No Data Found</button>");
     action = 'active';
    }
    else
    {
     $('#load_data_message').html("<button type='button' class='btn btn-warning'>Please Wait....</button>");
     action = "inactive";
    }
   }
  });
 }

 if(action == 'inactive')
 {
  action = 'active';
  load_country_data(limit, start);
 }
 $(window).scroll(function(){
  if($(window).scrollTop() + $(window).height() > $("#load_data").height() && action == 'inactive')
  {
   action = 'active';
   start = start + limit;
   setTimeout(function(){
    load_country_data(limit, start);
   }, 1000);
  }
 });
 
});
</script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-p34f1UUtsS3wqzfto5wAAmdvj+osOnFyQFpp4Ua3gs/ZVWx6oOypYoCJhGGScy+8" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.min.js" integrity="sha384-lpyLfhYuitXl2zRZ5Bn2fqnhNAKOAaM/0Kr9laMspuaMiZfGmfwRNFh8HlMy49eQ" crossorigin="anonymous"></script>
    -->
  </body>
</html>