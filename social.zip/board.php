<?php
    include"database.php";
    session_start();
    
    if(!isset($_SESSION["UID"]))
    {
        echo"<script>window.open('index.php?mes=Access Denied...','_self');</script>";
        
    }   
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/board.css">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-wEmeIV1mKuiNpC+IOBjI7aAzPcEZeedi5yW5f2yOq55WWLwNGmvvx4Um1vskeMj0" crossorigin="anonymous">
<!-- Custom styles for this page -->
   
    <title>Post Page</title>
  </head>
  <body>
<?php include 'header.php';?>

 <section id="board">
   <div class="container">
    <div class="tableranks">
      <div class="row formbot">
        
        <div class="col-md-4"></div>
        <div class="col-md-4">
          <form>
              <div class="commentbox">
            <input type="text" id="myInputform1" onkeyup="searchtable()" placeholder="Search for names.." title="Type in a name"class="form-control">
            <button><i class="fas fa-search"></i></button>
          </div>
            </form>
        </div>
        <!----end of col--->
        <div class="col-md-4"></div>    
      </div>
      <!----end of row---->



<div class="tablecover">
<table id="myTableform1" class="table table-striped">
  <thead>
     <th>Rank</th>
    <th>Name</th>
    <th >To.Votes</th>
      <th >Percentage(%)</th>
  </thead>
<?php
           
            $s="SELECT * FROM user ORDER BY UPRANK DESC limit 20";
            
                                $res=$db->query($s);
                                if($res->num_rows>0)
                                {
                                    $i=0;
                                    while($r=$res->fetch_assoc())
                                    {
                                        $i++;
                                        echo "
                         
 
                                       <tr>
                            <td>{$i}</td>
                            <td><a href='userhome.php?id={$r["UID"]}' class='btnr' style='color:black;text-decoration:none;font-weight:600; '>{$r["UTNAME"]}</a></td>
                            <td>{$r["UNPRANK"]}</td>
                            <td>{$r["UPRANK"]}</td>
                          </tr>  ";
                                    }
                                }
                                else
                                {
                                    echo "No Record Found";
                                }
                            
                            
            
          ?>


  <thead>
     <th>Rank</th>
    <th>Name</th>
    <th >To.Votes</th>
      <th >Percentage(%)</th>
  </thead>
 
  
</table>
    </div>
    <!--------end of table ranks--->
     </div>
     <!-----end of table cover----->
   </div>
 </section>
 <!-----end of board----->
<?php include 'footer.php';?>

<script>
function searchtable() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInputform1");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTableform1");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[1];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-p34f1UUtsS3wqzfto5wAAmdvj+osOnFyQFpp4Ua3gs/ZVWx6oOypYoCJhGGScy+8" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.min.js" integrity="sha384-lpyLfhYuitXl2zRZ5Bn2fqnhNAKOAaM/0Kr9laMspuaMiZfGmfwRNFh8HlMy49eQ" crossorigin="anonymous"></script>
    -->
  </body>
</html>