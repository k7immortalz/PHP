<?php
	include"database.php";
	session_start();
	
	$s="delete from market where PRID={$_GET["id"]}";
	$db->query($s);
	echo "<script>window.open('viewproducts.php?mes=Data Deleted.','_self');</script>"
?>