-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 21, 2021 at 05:25 AM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `college`
--

-- --------------------------------------------------------

--
-- Table structure for table `coulogin`
--

CREATE TABLE `coulogin` (
  `couid` varchar(200) NOT NULL,
  `passcode` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `coulogin`
--

INSERT INTO `coulogin` (`couid`, `passcode`) VALUES
('c111', 'c111'),
('c222', 'c222'),
('c333', '12345'),
('c555', 'test');

-- --------------------------------------------------------

--
-- Table structure for table `counsillar`
--

CREATE TABLE `counsillar` (
  `cousid` varchar(200) NOT NULL,
  `Couname` varchar(200) NOT NULL,
  `YOJ` varchar(200) NOT NULL,
  `Deptid` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `counsillar`
--

INSERT INTO `counsillar` (`cousid`, `Couname`, `YOJ`, `Deptid`) VALUES
('c111', 'raja', 'naddd', 1),
('c333', 'valen', '2', 0),
('c555', 'raju', 'red', 3);

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `usn` varchar(200) DEFAULT NULL,
  `couid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`usn`, `couid`) VALUES
('a111', 1);

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `Deptid` int(20) NOT NULL,
  `dname` varchar(200) NOT NULL,
  `hod` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`Deptid`, `dname`, `hod`) VALUES
(1, 'ECE', 'Hemalatha'),
(2, 'EEE', 'Jhon'),
(3, 'MECH', 'Raju'),
(4, 'CVIL', 'Ram');

-- --------------------------------------------------------

--
-- Table structure for table `dependents`
--

CREATE TABLE `dependents` (
  `usn` varchar(200) DEFAULT NULL,
  `dname` varchar(200) NOT NULL,
  `relation` varchar(200) NOT NULL,
  `rname` varchar(200) NOT NULL,
  `gender` varchar(200) NOT NULL,
  `phno` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `dependents`
--

INSERT INTO `dependents` (`usn`, `dname`, `relation`, `rname`, `gender`, `phno`) VALUES
('a111', 'kesa', 'Father', 'redffff', 'Male', '23453444444'),
('a222', 'test', 'Father', 'hddd', 'Male', '3333333333333333');

-- --------------------------------------------------------

--
-- Table structure for table `engmarks`
--

CREATE TABLE `engmarks` (
  `usn` varchar(200) DEFAULT NULL,
  `sem` varchar(200) NOT NULL,
  `cgpa` varchar(200) NOT NULL,
  `sgpa` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `email` varchar(200) NOT NULL,
  `passcode` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `email`, `passcode`) VALUES
(1, 'student@gmail.com', 'student'),
(2, 'cadmin@gmail.com', 'cadmin'),
(3, 'admin@gmail.com', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `marks`
--

CREATE TABLE `marks` (
  `usn` varchar(200) DEFAULT NULL,
  `sname` varchar(200) NOT NULL,
  `spac` varchar(200) NOT NULL,
  `cname` varchar(200) NOT NULL,
  `cpuc` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `marks`
--

INSERT INTO `marks` (`usn`, `sname`, `spac`, `cname`, `cpuc`) VALUES
('a111', 'frder', '34', 'frdreee', '23'),
('a222', 'frder', '23', 'frdr', '23');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `usn` varchar(200) NOT NULL,
  `Fname` varchar(200) NOT NULL,
  `Mname` varchar(200) NOT NULL,
  `Lname` varchar(200) NOT NULL,
  `Email` varchar(200) NOT NULL,
  `Dob` date NOT NULL,
  `Age` int(20) NOT NULL,
  `deptid` int(20) DEFAULT NULL,
  `cousid` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`usn`, `Fname`, `Mname`, `Lname`, `Email`, `Dob`, `Age`, `deptid`, `cousid`) VALUES
('a111', 'kesa', 'tre', 'n', 'test@gmail.com', '2021-12-04', 29, 1, 'c111'),
('a222', 'test', 'test', 't', 'test2@gmail.com', '2021-12-04', 23, 1, 'c555'),
('a333', 'test', 'test', 'n', 'test9@gmail.com', '2021-04-04', 29, 1, 'c555');

-- --------------------------------------------------------

--
-- Table structure for table `studentcocuri`
--

CREATE TABLE `studentcocuri` (
  `usn` varchar(200) DEFAULT NULL,
  `cluborg` varchar(200) NOT NULL,
  `points` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `studentcocuri`
--

INSERT INTO `studentcocuri` (`usn`, `cluborg`, `points`) VALUES
('a111', 'edl', '223');

-- --------------------------------------------------------

--
-- Table structure for table `studentlogin`
--

CREATE TABLE `studentlogin` (
  `suid` varchar(200) NOT NULL,
  `passcode` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `studentlogin`
--

INSERT INTO `studentlogin` (`suid`, `passcode`) VALUES
('a111', 'name'),
('a222', 'a222'),
('a333', 'test');

-- --------------------------------------------------------

--
-- Table structure for table `studentphno`
--

CREATE TABLE `studentphno` (
  `usn` varchar(200) DEFAULT NULL,
  `phno` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `studentphno`
--

INSERT INTO `studentphno` (`usn`, `phno`) VALUES
('a111', '2348907777'),
('a222', '2345678901'),
('a333', '9876543210');

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `courseCode` int(20) NOT NULL,
  `sem` varchar(200) NOT NULL,
  `courseTitle` varchar(200) NOT NULL,
  `regft` varchar(200) NOT NULL,
  `credits` varchar(200) NOT NULL,
  `dept` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`courseCode`, `sem`, `courseTitle`, `regft`, `credits`, `dept`) VALUES
(1, '1', 'hdd', 'edrf', '30', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `counsillar`
--
ALTER TABLE `counsillar`
  ADD PRIMARY KEY (`cousid`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD KEY `courses_ibfk_1` (`usn`),
  ADD KEY `couid` (`couid`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`Deptid`);

--
-- Indexes for table `dependents`
--
ALTER TABLE `dependents`
  ADD KEY `dependents_ibfk_1` (`usn`);

--
-- Indexes for table `engmarks`
--
ALTER TABLE `engmarks`
  ADD KEY `engmarks_ibfk_1` (`usn`);

--
-- Indexes for table `marks`
--
ALTER TABLE `marks`
  ADD KEY `marks_ibfk_1` (`usn`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`usn`),
  ADD UNIQUE KEY `Email` (`Email`),
  ADD KEY `student_ibfk_1` (`cousid`),
  ADD KEY `student_ibfk_2` (`deptid`);

--
-- Indexes for table `studentcocuri`
--
ALTER TABLE `studentcocuri`
  ADD KEY `studentcocuri_ibfk_1` (`usn`);

--
-- Indexes for table `studentphno`
--
ALTER TABLE `studentphno`
  ADD KEY `studentphno_ibfk_1` (`usn`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`courseCode`),
  ADD KEY `subjects_ibfk_1` (`dept`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `Deptid` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `courseCode` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `courses`
--
ALTER TABLE `courses`
  ADD CONSTRAINT `courses_ibfk_1` FOREIGN KEY (`usn`) REFERENCES `student` (`usn`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `courses_ibfk_2` FOREIGN KEY (`couid`) REFERENCES `subjects` (`courseCode`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `dependents`
--
ALTER TABLE `dependents`
  ADD CONSTRAINT `dependents_ibfk_1` FOREIGN KEY (`usn`) REFERENCES `student` (`usn`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `engmarks`
--
ALTER TABLE `engmarks`
  ADD CONSTRAINT `engmarks_ibfk_1` FOREIGN KEY (`usn`) REFERENCES `student` (`usn`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `marks`
--
ALTER TABLE `marks`
  ADD CONSTRAINT `marks_ibfk_1` FOREIGN KEY (`usn`) REFERENCES `student` (`usn`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `student`
--
ALTER TABLE `student`
  ADD CONSTRAINT `student_ibfk_1` FOREIGN KEY (`cousid`) REFERENCES `counsillar` (`cousid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `student_ibfk_2` FOREIGN KEY (`deptid`) REFERENCES `department` (`Deptid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `studentcocuri`
--
ALTER TABLE `studentcocuri`
  ADD CONSTRAINT `studentcocuri_ibfk_1` FOREIGN KEY (`usn`) REFERENCES `student` (`usn`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `studentphno`
--
ALTER TABLE `studentphno`
  ADD CONSTRAINT `studentphno_ibfk_1` FOREIGN KEY (`usn`) REFERENCES `student` (`usn`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `subjects`
--
ALTER TABLE `subjects`
  ADD CONSTRAINT `subjects_ibfk_1` FOREIGN KEY (`dept`) REFERENCES `department` (`Deptid`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
