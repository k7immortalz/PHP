<?php
error_reporting(E_ERROR | E_PARSE);
   include("config.php");
   session_start();
  $ids = $_SESSION['login_user'];
  if($ids==3){
    if($_SERVER["REQUEST_METHOD"] == "POST") {
        $usn = $_POST['USN'];
        $Fname =$_POST['Fname']; 
        $Mname =$_POST['Mname']; 
        $Lname =$_POST['Lname'];
        $email =$_POST['email'];
        $dob =$_POST['dob'];
        $age =$_POST['age'];
        $deptid =$_POST['deptid'];
        $couid =$_POST['couid'];
        $sname =$_POST['sname'];
        $sper =$_POST['sper'];
        $cname =$_POST['cname'];
        $cper =$_POST['cper'];
        $phno =$_POST['phno'];
        $srel =$_POST['srel'];
        $sranme =$_POST['sranme'];
        $Gender =$_POST['Gender'];
        $rphno =$_POST['rphno'];
        $passcode =$_POST['passcode'];
        


        $sql = "INSERT INTO student (usn, Fname, Mname, Lname, Email, Dob, Age, deptid, cousid)
    VALUES ('$usn', '$Fname', '$Mname','$Lname', '$email', '$dob','$age', '$deptid', '$couid')";
    
    if (mysqli_query($db, $sql)) {
        $sql1 = "INSERT INTO marks (usn, sname, spac, cname, cpuc)
        VALUES ('$usn', '$sname', '$sper','$cname', '$cper')";
        if (mysqli_query($db, $sql1)) {
            $sql2 = "INSERT INTO studentphno (usn, phno)
            VALUES ('$usn', '$phno')";
            if (mysqli_query($db, $sql2)) {
                $sql3 = "INSERT INTO dependents (usn, dname, relation, rname, gender, phno)
                VALUES ('$usn', '$Fname','$srel', '$sranme','$Gender', '$rphno')";
                if (mysqli_query($db, $sql3)) {
                    $sql4 = "INSERT INTO studentlogin (suid, passcode)
                VALUES ('$usn', '$passcode')";
                if (mysqli_query($db, $sql4)) {
                    header("location: studenth.php"); 
                } 
                }

                }  
            }
        }
     else {
      echo "Error: " . $sql . "<br>" . mysqli_error($db);
      
    }

        
    }    

  }
?>